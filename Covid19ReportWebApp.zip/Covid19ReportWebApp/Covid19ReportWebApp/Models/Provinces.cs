﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Covid19ReportWebApp.Models
{
    public class Provinces
    {
        public string Province { get; set; }
        public int Cases { get; set; }
        public int Deaths { get; set; }

    }
}
