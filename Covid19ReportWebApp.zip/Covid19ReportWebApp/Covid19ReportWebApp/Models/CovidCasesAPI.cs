﻿
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.Json;
using System.Xml.Serialization;
using System.IO;


namespace Covid19ReportWebApp.Models
{
    public class CovidCasesAPI
    {
        public async Task GetRegion(List<Report> reportList)
        {

            var client = new HttpClient();
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://covid-19-statistics.p.rapidapi.com/reports"),
                Headers =
                        {
                            { "x-rapidapi-key", "3c8bc9d068msh937016bda19099bp1c5581jsn89b151823541" },
                            { "x-rapidapi-host", "covid-19-statistics.p.rapidapi.com" },
                        },
            };
            using (var response = await client.SendAsync(request))
            {
                response.EnsureSuccessStatusCode();

                var jsonString = response.Content.ReadAsStringAsync().Result;
                JsonDocument doc = JsonDocument.Parse(jsonString);

                JsonElement root = doc.RootElement;
                JsonElement reportElement = root.GetProperty("data");


                foreach (JsonElement data in reportElement.EnumerateArray())
                {
                    Report report = new Report();

                    //Get Confirmed
                    if (data.TryGetProperty("confirmed", out JsonElement confirmedElement))
                    {
                        report.Cases = confirmedElement.GetInt32();
                    }
                    else
                    {
                        report.Cases = 0;
                    }
                    //Get Deaths
                    if (data.TryGetProperty("deaths", out JsonElement deathElement))
                    {
                        report.Deaths = deathElement.GetInt32();
                    }
                    else
                    {
                        report.Deaths = 0;
                    }
                    //Get Region
                    if (data.TryGetProperty("region", out JsonElement regionElement))
                    {
                        if (regionElement.TryGetProperty("name", out JsonElement nameElement))
                        {
                            report.Region = nameElement.ToString();
                        }
                        else
                        {
                            report.Region = "NA";
                        }
                    }
                    else
                    {
                        report.Region = "NA";
                    }


                    //Add to List
                    reportList.Add(report);

                }
            }
        }

        public async Task GetProvince(List<Provinces> provincesList, string iso)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://covid-19-statistics.p.rapidapi.com/reports?iso=" + iso),
                Headers =
                        {
                            { "x-rapidapi-key", "3c8bc9d068msh937016bda19099bp1c5581jsn89b151823541" },
                            { "x-rapidapi-host", "covid-19-statistics.p.rapidapi.com" },
                        },
            };
            using (var response = await client.SendAsync(request))
            {
                response.EnsureSuccessStatusCode();

                var jsonString = response.Content.ReadAsStringAsync().Result;

                JsonDocument doc = JsonDocument.Parse(jsonString);

                JsonElement root = doc.RootElement;
                JsonElement reportElement = root.GetProperty("data");

                foreach (JsonElement data in reportElement.EnumerateArray())
                {
                    Provinces provinces = new Provinces();

                    //Get Confirmed
                    if (data.TryGetProperty("confirmed", out JsonElement confirmedElement))
                    {
                        provinces.Cases = confirmedElement.GetInt32();
                    }
                    else
                    {
                        provinces.Cases = 0;
                    }
                    //Get Deaths
                    if (data.TryGetProperty("deaths", out JsonElement deathElement))
                    {
                        provinces.Deaths = deathElement.GetInt32();
                    }
                    else
                    {
                        provinces.Deaths = 0;
                    }
                    //Get Region
                    if (data.TryGetProperty("region", out JsonElement regionElement))
                    {
                        if (regionElement.TryGetProperty("province", out JsonElement provinceElement))
                        {
                            provinces.Province = provinceElement.ToString();
                        }
                        else
                        {
                            provinces.Province = "NA";
                        }
                    }
                    else
                    {
                        provinces.Province = "NA";
                    }
                    //Add to List
                    provincesList.Add(provinces);

                }
            }
        }

        public async Task<string> GetRegionString()
        {
            string jsonResult = "";

            var client = new HttpClient();
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://covid-19-statistics.p.rapidapi.com/reports"),
                Headers =
                        {
                            { "x-rapidapi-key", "3c8bc9d068msh937016bda19099bp1c5581jsn89b151823541" },
                            { "x-rapidapi-host", "covid-19-statistics.p.rapidapi.com" },
                        },
            };
            using (var response = await client.SendAsync(request))
            {
                response.EnsureSuccessStatusCode();
                var jsonString = response.Content.ReadAsStringAsync().Result;
                jsonResult = jsonString;    
            }

            return jsonResult;
        }

        //Download Json Region 
        public string ReportModelToJson(Report report)
        {
            string jsonString = "";
            jsonString = JsonSerializer.Serialize(report);
            return jsonString;
        }
        //Download XML Region 
        public string ReportModelToXml(Report report)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Report));
            using(StringWriter stringWriter = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, report);
                return stringWriter.ToString();
            }
        }
        //Download Csv Region 
        public string ReportModelToCsv(Report report)
        {
            string csvString = "";

            csvString = report.Region + "," + report.Cases + "," + report.Deaths + "\n";

            return csvString;
        }
        //Download Json Provinces 
        public string ProvincesModelToJson(Provinces provinces)
        {
            string jsonString = "";
            jsonString = JsonSerializer.Serialize(provinces);
            return jsonString;
        }
        //Download XML Provinces
        public string ProvincesModelToXml(Provinces provinces)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Provinces));
            using (StringWriter stringWriter = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, provinces);
                return stringWriter.ToString();
            }
        }
        //Download CSV Provinces
        public string ProvincesModelToCsv(Provinces provinces)
        {
            string csvString = "";

            csvString = provinces.Province + "," + provinces.Cases + "," + provinces.Deaths + "\n";

            return csvString;
        }

    }
}
