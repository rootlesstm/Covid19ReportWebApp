﻿/*@utor: Tulio Alberto Maritnez Gomez
   date: 27/03/2021                 */
using Covid19ReportWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Web;
//using Newtonsoft.Json;

namespace Covid19ReportWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Report> reportList = new List<Report>();
            //Wait for data
            casesAPI.GetRegion(reportList).Wait();
            //Sort List
            var sortReportList = reportList.OrderByDescending(o => o.Cases).Take(10);

            return View(sortReportList);
            
        }

        //Provinces
        public  ActionResult ProvincesView(string iso)
        {
            
            CovidCasesAPI casesAPI = new CovidCasesAPI();
            List<Provinces> provincestList = new List<Provinces>();
            //Get html
            
            //Get Data
            casesAPI.GetProvince(provincestList, iso).Wait();

            //Sort List
            var sortProvincesList = provincestList.OrderByDescending(o => o.Cases).Take(10);

            return View(sortProvincesList);
            
        }

        //Download JsonFile
        public ActionResult JsonFileRegion()
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Report> reportList = new List<Report>();
            //Wait for data
            casesAPI.GetRegion(reportList).Wait();
            //Sort List
            var sortReportList = reportList.OrderByDescending(o => o.Cases).Take(10);

            foreach(Report report in sortReportList)
            {
                data += casesAPI.ReportModelToJson(report);
            }

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcases.json";

            return output;
        }
        //Download Xml File
        public ActionResult XmlFileRegion()
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Report> reportList = new List<Report>();
            //Wait for data
            casesAPI.GetRegion(reportList).Wait();
            //Sort List
            var sortReportList = reportList.OrderByDescending(o => o.Cases).Take(10);

            foreach (Report report in sortReportList)
            {
                data += casesAPI.ReportModelToXml(report);
            }

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcases.xml";

            return output;
        }
        //Download CSV File
        public ActionResult CsvFileRegion()
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Report> reportList = new List<Report>();
            //Wait for data
            casesAPI.GetRegion(reportList).Wait();
            //Sort List
            var sortReportList = reportList.OrderByDescending(o => o.Cases).Take(10);

            foreach (Report report in sortReportList)
            {
                data += casesAPI.ReportModelToCsv(report);
            }

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcases.csv";

            return output;
        }

        //Download Json for Provinces
        public ActionResult JsonFileProvinces(string iso)
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Provinces> provincesList = new List<Provinces>();
            //Wait for data
            casesAPI.GetProvince(provincesList, iso).Wait();
            //Sort List
            var sortReportList = provincesList.OrderByDescending(o => o.Cases).Take(10);

            foreach (Provinces provinces in sortReportList)
            {
                data += casesAPI.ProvincesModelToJson(provinces);
            }
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcasesprovinces.json";

            return output;
        }
        //Download Xml File fro Provinces
        public ActionResult XmlFileProvinces(string iso)
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Provinces> provincesList = new List<Provinces>();
            //Wait for data
            casesAPI.GetProvince(provincesList, iso).Wait();
            //Sort List
            var sortProvinceList = provincesList.OrderByDescending(o => o.Cases).Take(10);

            foreach (Provinces provinces in sortProvinceList)
            {
                data += casesAPI.ProvincesModelToXml(provinces);
            }

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcasesprovinces.xml";

            return output;
        }
        //Download CSV Fiel for Provinces
        public ActionResult CsvFileProvinces(string iso)
        {
            string data = "";

            CovidCasesAPI casesAPI = new CovidCasesAPI();
            //grid data
            List<Provinces> provincesList = new List<Provinces>();
            //Wait for data
            casesAPI.GetProvince(provincesList, iso).Wait();
            //Sort List
            var sortProvincesList = provincesList.OrderByDescending(o => o.Cases).Take(10);

            foreach (Provinces provinces in sortProvincesList)
            {
                data += casesAPI.ProvincesModelToCsv(provinces);
            }

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(data);
            var output = new FileContentResult(bytes, "application/octet-stream");
            output.FileDownloadName = "covidcasesprovinces.csv";

            return output;
        }

    }
}
